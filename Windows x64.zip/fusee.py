# Ajoutez vos includes ici

PRENOM = "John"
NOM = "Doe"
MATRICULE = "1234567"

# Ajoutez votre code ici